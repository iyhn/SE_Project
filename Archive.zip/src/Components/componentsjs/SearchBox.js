import React from 'react';
import '../componentscss/Profile.css';

const SearchBox = () => (
    <div>
    <div style={{borderBottom: '2px solid',borderColor:'rgb(237,245,250)', height:'110px', padding:'10px 20px'}}>
        
    </div>
    <div style={{borderBottom: '2px solid',borderColor:'rgb(237,245,250)', height:'110px', padding:'10px 20px'}}>
        
    </div>
    <div style={{borderBottom: '2px solid',borderColor:'rgb(237,245,250)', height:'110px', padding:'10px 20px'}}>
        
    </div>
    <div style={{borderBottom: '2px solid',borderColor:'rgb(237,245,250)', height:'110px', padding:'10px 20px'}}>
        
    </div>
    <div style={{borderBottom: '2px solid',borderColor:'rgb(237,245,250)', height:'110px', padding:'10px 20px'}}>
        
    </div>
    </div>
)

export default SearchBox;