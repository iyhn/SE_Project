import React from 'react';
import '../App.css';
import api from '../api/api';
import HeaderContainer from './HeaderContainer';
import Loading from '../Components/componentsjs/Loading';
import ProfileBox from '../Components/componentsjs/ProfileBox';
import SearchBox from '../Components/componentsjs/SearchBox';
import './Home.css';

class App extends React.Component {
  
  constructor(props) {
    super(props);
    this.state = {
      fetched: true
    }
  }

  componentDidMount (){
   // api.profile().then( () => this.setState({fetched: true}));
  };

  render() {
    return (
      <div style={{backgroundColor : "rgb(250,246,237)", width: '100vw', height: '100vh'}}>
        {this.state.fetched ? null : <Loading/>}
        <HeaderContainer/>
        
        <div className='homePage'>
          <div className='container'>
            <div className='leftContainer'>
              <div className='profilebox'>
                <ProfileBox/>
              </div>
              <div className='recommendtask'>
               
              </div>
            </div>
            <div className='bodyContainer'>
              <div>
                <SearchBox/>
              </div>
            </div>
            <div className='rightContainer'>
              <div className='recommend'>

              </div>
            </div>
          </div>
        </div>

      </div>
    );
  }
}

export default App;
